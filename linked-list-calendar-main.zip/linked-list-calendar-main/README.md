# LinkedListCalendar

Data structure activity

To run on Unix-like OS:
```
g++ -O2 -pipe -Wall -Wextra -std=c++17 main.cpp Calendar/calendar.cpp Commitment/commitment.cpp -o main && ./main && rm main
```

Docs:
```
https://docs.google.com/document/d/1u2ryTI_oI6e_XH5cVitAntEXJocjDFt2clu8-KClLm8/edit?usp=sharing
```