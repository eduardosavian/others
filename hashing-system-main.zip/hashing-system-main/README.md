# Hashing-System

## Alunos

- Eduardo Savian e Felipe de Negredo

## To run (Only Unix like)

```
clear && make && ./src/Main && make clean
```
