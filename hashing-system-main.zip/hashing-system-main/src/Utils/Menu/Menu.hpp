#ifndef MENU_HPP
#define MENU_HPP

#include "../../Classes/Library/Library.hpp"

class Menu {
    public:
        void mainMenu();
        void run();
};

#endif