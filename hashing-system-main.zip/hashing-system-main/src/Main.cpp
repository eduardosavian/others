#include "Utils/Menu/Menu.hpp"

int main() {
    Menu menu = Menu();
    menu.run();

    return 0;
}