# Tic-Tac-Toe

## Description

Tic Tac Toe with trees

**[Presetation Link](https://youtu.be/5U3J02R7nBw)**

Students: Eduardo Savian e Felipe de Negredo

## How to run, only Unix-like

### Clear Terminal

```bash
clear
```

### Change directory

```bash
cd src/
```

### Compile

```bash
make all
```

### Run

```bash
./exec
```

### Clean

```bash
make clean
```

### Or everything in a command

```bash
clear && make all && ./exec && make clean
```
