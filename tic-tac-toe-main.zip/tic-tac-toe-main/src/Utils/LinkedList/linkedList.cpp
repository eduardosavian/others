#ifndef LINKEDLIST_CPP
#define LINKEDLIST_CPP

#include "linkedList.hpp"

namespace ll {
    Node::Node(const brd::Board& board) : board(board), next(nullptr) {}

    LinkedList::LinkedList() : head(nullptr), tail(nullptr) {}

    LinkedList::~LinkedList() {
        Clear();
    }

    void LinkedList::Push(const brd::Board& board) {
        Node* newNode = new Node(board);

        if (head == nullptr) {
            head = newNode;
            tail = newNode;
        } else {
            tail->next = newNode;
            tail = newNode;
        }
    }

    void LinkedList::Clear() {
        Node* current = head;
        while (current != nullptr) {
            Node* nextNode = current->next;
            delete current;
            current = nextNode;
        }
        head = nullptr;
        tail = nullptr;
    }
} // namespace ll


#endif