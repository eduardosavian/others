#ifndef LINKEDLIST_HPP
#define LINKEDLIST_HPP

#include "../Board/board.hpp"

namespace ll {
    struct Node {
        brd::Board board;
        Node* next;

        Node(const brd::Board& board);
    };

    struct LinkedList {
        Node* head;
        Node* tail;

        LinkedList();
        ~LinkedList();

        void Push(const brd::Board& board);
        void Clear();
    };
} // namespace ll

#endif
