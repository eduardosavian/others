#ifndef TABLE_CPP
#define TABLE_CPP

#include "board.hpp"

brd::Board::Board() {
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
                this->board[i][j] = ' ';
}


char& brd::Board::Get(int i, int j) {
    return this->board[i][j];
}


void brd::Board::Set(int i, int j, char value) {
    this->board[i][j] = value;
}


bool brd::Board::IsValid(int x, int y) {
    int boardSize = 3;

    if (x < 0 || x >= boardSize) {
        std::cout << "Invalid x position: " << ++x << std::endl;
        return false;
    }

    if (y < 0 || y >= boardSize) {
        std::cout << "Invalid y position: " << ++y << std::endl;
        return false;
    }

    if (board[x][y] != ' ') {
        std::cout << "Position (" << ++x << "," << ++y << ") is already occupied" << std::endl;
        return false;
    }

    return true;
}


void brd::Board::Move(char value) {
    int i, j = 0;
    while(true) {
        std::cout << "Choose a position X[1-3]: ";
        std::cin >> i;
        std::cout << "Choose a position Y[1-3]: ";
        std::cin >> j;
        i--;
        j--;

        if(IsValid(i, j)) {
            Set(i, j, value);
            break;
        } else
            std::cout << "Invalid position\n";
    }
}


bool brd::Board::IsVictory() {
    int boardSize = 3;

    // Verificar linhas
    for (int i = 0; i < boardSize; i++) {
        if (board[i][0] != ' ') {
            bool victory = true;
            for (int j = 1; j < boardSize; j++) {
                if (board[i][j] != board[i][0]) {
                    victory = false;
                    break;
                }
            }
            if (victory) return true;
        }
    }

    // Verificar colunas
    for (int j = 0; j < boardSize; j++) {
        if (board[0][j] != ' ') {
            bool victory = true;
            for (int i = 1; i < boardSize; i++) {
                if (board[i][j] != board[0][j]) {
                    victory = false;
                    break;
                }
            }
            if (victory) return true;
        }
    }

    // Verificar diagonal principal
    if (board[0][0] != ' ') {
        bool victory = true;
        for (int i = 1; i < boardSize; i++) {
            if (board[i][i] != board[0][0]) {
                victory = false;
                break;
            }
        }
        if (victory) return true;
    }

    // Verificar diagonal secundária
    if (board[0][boardSize - 1] != ' ') {
        bool victory = true;
        for (int i = 1; i < boardSize; i++) {
            if (board[i][boardSize - 1 - i] != board[0][boardSize - 1]) {
                victory = false;
                break;
            }
        }
        if (victory) return true;
    }

    return false;
}


bool brd::Board::IsFull() {
    int boardSize = 3;

    for (int i = 0; i < boardSize; i++) {
        for (int j = 0; j < boardSize; j++) {
            if (board[i][j] == ' ') {
                return false;  // Se houver uma posição vazia, o tabuleiro não está cheio
            }
        }
    }

    return true;  // Se todas as posições estiverem ocupadas, o tabuleiro está cheio
}


void brd::Board::Print() {
    std::cout << "  1 2 3" << std::endl;
    for (int i = 0; i < 3; i++) {
        std::cout << i + 1 << " ";
        for (int j = 0; j < 3; j++)
            std::cout << this->board[i][j] << " ";
        std::cout << std::endl;
    }
}


#endif
