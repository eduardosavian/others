#ifndef TABLE_HPP
#define TABLE_HPP

#include <iostream>
#include <string>

namespace brd{
struct Board {
    char board[3][3];

    Board();

    char& Get(int i, int j);
    void Set(int i, int j, char value);

    bool IsValid(int x, int y);
    void Move(char value);

    bool IsVictory();
    bool IsFull();

    void Print();
};
}

#endif