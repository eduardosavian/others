#ifndef TREE_HPP
#define TREE_HPP

#include "../LinkedList/linkedList.hpp"
#include "../Board/board.hpp"

namespace tr {
    struct Node {
        brd::Board board;
        ll::LinkedList children;

        Node(const brd::Board& board);
    };

    struct Tree {
        Node* root;

        Tree();
        ~Tree();

        void DestroyTree(Node* node);
        void PerformComputerMove(brd::Board& board, char value);
        int Minimax(Node* node, bool isMaximizingPlayer);
    };
}

#endif
