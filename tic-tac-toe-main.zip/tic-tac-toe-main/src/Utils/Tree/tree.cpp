#include "tree.hpp"

namespace tr {
    Node::Node(const brd::Board& board) : board(board) {}

    Tree::Tree() : root(nullptr) {}

    Tree::~Tree() {
        DestroyTree(root);
    }

    void Tree::DestroyTree(Node* node) {
        if (node == nullptr) {
            return;
        }

        node->children.Clear();

        delete node;
    }

    void tr::Tree::PerformComputerMove(brd::Board& board, char value) {
        if (root == nullptr) {
            root = new Node(board);
        }

        int bestScore = -1000;
        int bestMoveX = -1;
        int bestMoveY = -1;

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (board.Get(i, j) == ' ') {
                    board.Set(i, j, value);
                    Node* newNode = new Node(board);
                    root->children.Push(newNode->board);
                    int moveScore = Minimax(newNode, false);
                    board.Set(i, j, ' ');

                    if (moveScore > bestScore) {
                        bestScore = moveScore;
                        bestMoveX = i;
                        bestMoveY = j;
                    }
                }
            }
        }

        board.Set(bestMoveX, bestMoveY, value);
    }

    int Tree::Minimax(Node* node, bool isMaximizingPlayer) {
        if (node->board.IsVictory()) {
            if (isMaximizingPlayer) {
                return -1;
            } else {
                return 1;
            }
        }

        if (node->board.IsFull()) {
            return 0;
        }

        int bestScore;
        if (isMaximizingPlayer) {
            bestScore = -1000;
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    if (node->board.Get(i, j) == ' ') {
                        node->board.Set(i, j, 'O');
                        Node* newNode = new Node(node->board);
                        node->children.Push(newNode->board);
                        int moveScore = Minimax(newNode, false);
                        node->board.Set(i, j, ' ');

                        bestScore = std::max(bestScore, moveScore);
                    }
                }
            }
        } else {
            bestScore = 1000;
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    if (node->board.Get(i, j) == ' ') {
                        node->board.Set(i, j, 'X');
                        Node* newNode = new Node(node->board);
                        node->children.Push(newNode->board);
                        int moveScore = Minimax(newNode, true);
                        node->board.Set(i, j, ' ');

                        bestScore = std::min(bestScore, moveScore);
                    }
                }
            }
        }

        return bestScore;
    }
} // namespace tr
