#ifndef MENU_CPP
#define MENU_CPP

#include "menu.hpp"

bool mnu::Menu::ChooseFirst() {
    srand(time(NULL));
    int random = rand() % 2;

    if (random == 0)
        return true;
    else
        return false;
}


void mnu::Menu::PlayerVsComputer(brd::Board board) {
    std::cout << "Player vs Computer\n";

    bool turn = ChooseFirst();

    tr::Tree tree;

    while (true) {
        if (turn) {
            std::cout << "Player's turn\n";
            board.Move('X');
            turn = false;
        } else {
            std::cout << "Computer's turn\n";
            if(board.Get(1, 1) == ' ') {
                board.Set(1, 1, 'O');
            } else {
                if(board.Get(0, 0) == ' ') {
                    board.Set(0, 0, 'O');
                } else {
                    tree.PerformComputerMove(board, 'O');
                }
            }
            turn = true;
        }

        board.Print();

        if(board.IsVictory()) {
            if (!turn)
                std::cout << "Player wins\n";
            else
                std::cout << "Computer wins\n";
            break;
        }

        if (board.IsFull()) {
            std::cout << "Draw\n";
            break;
        }
    }
}



void mnu::Menu::PlayerVsPlayer(brd::Board board) {
    std::cout << "Player vs Player\n";

    bool turn = ChooseFirst();

    if (turn) {
        std::cout << "Player 1 starts\n";
    } else {
        std::cout << "Player 2 starts\n";
    }

    while (true) {
        if (turn) {
            std::cout << "Player 1's turn\n";
            board.Move('X');
            turn = false;
        } else {
            std::cout << "Player 2's turn\n";
            board.Move('O');
            turn = true;
        }

        board.Print();

        if(board.IsVictory()) {
            if (!turn)
                std::cout << "Player 1 wins\n";
            else
                std::cout << "Player 2 wins\n";
            break;
        }

        if (board.IsFull()) {
            std::cout << "Draw\n";
            break;
        }
    }
}


void mnu::Menu::ComputerVsComputer(brd::Board board) {
    std::cout << "Computer vs Computer\n";

    bool turn = ChooseFirst();

    if (turn) {
        std::cout << "Computer 1 starts\n";
        board.Set(1, 1, 'X');
        board.Print();

        turn = false;
    } else {
        std::cout << "Computer 2 starts\n";
        board.Set(1, 1, 'O');
        board.Print();
        turn = true;
    }

    tr::Tree tree;

    while (true) {
        if (turn) {
            std::cout << "Computer 1's turn\n";
            tree.PerformComputerMove(board, 'X');
            turn = false;
        } else {
            std::cout << "Computer 2's turn\n";
            tree.PerformComputerMove(board, 'O');
            turn = true;
        }

        board.Print();

        if(board.IsVictory()) {
            if (!turn)
                std::cout << "Computer 1 wins\n";
            else
                std::cout << "Computer 2 wins\n";
            break;
        }

        if (board.IsFull()) {
            std::cout << "Draw\n";
            break;
        }
    }
}


std::string mnu::Menu::Options() {
    std::string option;

    std::cout << "Tic Tac Toe\n";
    std::cout << "Options:\n";
    std::cout << "1 - Player vs Player\n";
    std::cout << "2 - Player vs Computer\n";
    std::cout << "3 - Computer vs Computer\n";
    std::cout << "4 - Exit\n";
    std::cout << "Choose an option: ";
    std::cin >> option;

    return option;
}


void mnu::Menu::Print() {
    brd::Board board = brd::Board();
    while(true) {
        std::string option = Options();
        system("clear");
        if (option == "1") {
            PlayerVsPlayer(board);
        } else if (option == "2") {
            PlayerVsComputer(board);
        } else if (option == "3") {
            ComputerVsComputer(board);
        } else if (option == "4") {
            std::cout << "Exit\n";
            break;
        } else {
            std::cout << "Invalid option\n\n";
        }
    }
}


void mnu::Menu::Run() {
    Print();
}


#endif