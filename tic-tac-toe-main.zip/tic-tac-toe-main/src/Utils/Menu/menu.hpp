#ifndef MENU_HPP
#define MENU_HPP

#include <iostream>
#include <string>
#include <ctime>

#include "../Board/board.hpp"
#include "../Tree/tree.hpp"

namespace mnu{
struct Menu {
    bool ChooseFirst();

    void PlayerVsComputer(brd::Board board);
    void PlayerVsPlayer(brd::Board board);
    void ComputerVsComputer(brd::Board board);

    std::string Options();

    void Run();
    void Print();
};
}

#endif