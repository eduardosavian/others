#include "Utils/Menu/menu.hpp"

int main() {
    mnu::Menu menu = mnu::Menu();
    menu.Run();

    return 0;
}